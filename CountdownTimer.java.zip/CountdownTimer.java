
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.awt.*;

public class CountdownTimer extends Application {
    private Timeline timeline;
    private int remainingSeconds;
    public static void main(String[] args) {
        launch(args);
    }
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Countdown Timer");
        TextField secondsTextField = new TextField();
       secondsTextField.setFont(Font.font(50));
        secondsTextField.setPrefColumnCount(3);
        secondsTextField.setAlignment(Pos.CENTER);
        secondsTextField.setFocusTraversable(false);
        Pane pane = new Pane(secondsTextField);
        StackPane stackPane = new StackPane(pane);
        Label countdownLabel = new Label();
        countdownLabel.setFont(Font.font(50));
        countdownLabel.setStyle("-fx-background-color: white;");
        countdownLabel.setAlignment(Pos.CENTER);
        countdownLabel.setFocusTraversable(false);
        secondsTextField.setOnAction(e -> {
            try {
                int seconds = Integer.parseInt(secondsTextField.getText());
                startCountdown(seconds, countdownLabel);
            } catch (NumberFormatException ex) {

                System.out.println("Invalid input. Please enter a valid integer.");
            }
        });
        stackPane.getChildren().addAll( secondsTextField, countdownLabel);
        Scene scene = new Scene(stackPane, 300, 200);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    private void startCountdown(int seconds, Label countdownLabel) {
        if (timeline != null) {
            timeline.stop();
        }
      remainingSeconds = seconds;
        timeline = new Timeline();
        timeline.setCycleCount(Animation.INDEFINITE);

        String audioFile = "https://liveexample.pearsoncmg.com/common/audio/anthem/anthem0.mp3";
        Media media = new Media(audioFile);
        MediaPlayer mediaPlayer = new MediaPlayer(media);
        KeyFrame keyFrame = new KeyFrame(Duration.seconds(1), new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                remainingSeconds--;
                if ( remainingSeconds <= 0) {
                    mediaPlayer.play();
                } if ( remainingSeconds >= 0) {
                    countdownLabel.setText(": " + remainingSeconds );
                }
            }
        });
        timeline.getKeyFrames().add(keyFrame);
        timeline.play();
    }
}

